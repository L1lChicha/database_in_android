package com.example.lab2;

public interface RecyclerViewItemClickListener {
    void onPhoneClick(int position);
}
